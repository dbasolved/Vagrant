#!/bin/bash

Usage()
{
    # Display Help
    echo "---------------------------------------------------------------------------------------------"
    echo "DBinstall.sh Usage Information"
    echo 
    echo "Syntax:"
    echo "DBinstall.sh \$1 \$2 \$3 \$4 \$5 \$6"
    echo 
    echo "\$1  : Database Name"
    echo "\$2  : Installation Type - Single Instance (SI) or Real Application Cluster (RAC)"
    echo "\$3  : CDB or Non-CDB Build - Boolean - true || false"
    echo "\$4  : Number of Pluggable Database (PDB) to build - resulting PDBs will be enumerated"
    echo "\$5  : Pluggable Database Name"
    echo "\$6  : Default Password to use"
    echo
    echo "-h   : Display this help message"
    echo
    echo
    echo "Example:"
    echo "\$ sh ./DBinstall.sh db SI true 1 dbtst Welcome1"
    echo 
    echo "--------------------------------------------------------------------------------------------"

}

#Default envrionment settings - Update if needed
export ORA_INVENTORY=/opt/app/oraInventory
export ORACLE_BASE=/opt/app/oracle
export ORACLE_HOME=/opt/app/oracle/product/19.3.0/dbhome_1
export ORACLE_CHARACTERSET=AL32UTF8
export ORACLE_EDITION=EE
export ORACLE_PWD=$6
export DB_VERSION=ORA19c

#Change as needed to build desired database (CDB/PDB)
#
#Notes
#If the database does not come up, then the environment variable (ORACLE_SID) needs to be chnaged to match what this script builds.
#
#
export ORACLE_NAME=$1.cst.gov
export ORACLE_SID=$1
export ORACLE_TYPE=$2
export CDBBOOLEN=$3
export PDBNUMBER=$4
export PDB_NAME=$5
export DATA_DIR=/opt/app/oracle/data
export FRA_DIR=/opt/app/oracle/fra
#export ASM_LOCATION_DATA=+DATA
#export ASM_LOCATION_ARCH=+ARCH
export STORAGETYPE=FS
export WALLET_LOCATION=/opt/app/oracle/wallet/tde
export WALLET_ROOT=/opt/app/oracle

if [ $1 == "-h" ];
then
    Usage
fi

if [ $# -ne 6 ];
then
    echo
    echo "You must enter exactly six (6) command line arguments"
    echo
    Usage

else
    echo "--------------------------------------------------"
    echo "INSTALLER: Started up                             "
    echo "--------------------------------------------------"

    mkdir -p $WALLET_ROOT/wallet

    cp /tmp/SETUP/ora-response/dbca.rsp.tmpl /tmp/SETUP/ora-response/dbca.rsp
    sed -i -e "s|###ORACLE_NAME###|$ORACLE_NAME|g" /tmp/SETUP/ora-response/dbca.rsp && \
    sed -i -e "s|###ORACLE_SID###|$ORACLE_SID|g" /tmp/SETUP/ora-response/dbca.rsp && \
    sed -i -e "s|###ORACLE_TYPE###|$ORACLE_TYPE|g" /tmp/SETUP/ora-response/dbca.rsp && \
    sed -i -e "s|###CDBBOOLEN###|$CDBBOOLEN|g" /tmp/SETUP/ora-response/dbca.rsp && \
    sed -i -e "s|###PDBNUMBER###|$PDBNUMBER|g" /tmp/SETUP/ora-response/dbca.rsp && \
    sed -i -e "s|###PDB_NAME###|$PDB_NAME|g" /tmp/SETUP/ora-response/dbca.rsp && \
    sed -i -e "s|###ORACLE_PWD###|$ORACLE_PWD|g" /tmp/SETUP/ora-response/dbca.rsp && \
    sed -i -e "s|###DATA_DIR###|$DATA_DIR|g" /tmp/SETUP/ora-response/dbca.rsp && \
    sed -i -e "s|###FRA_DIR###|$FRA_DIR|g" /tmp/SETUP/ora-response/dbca.rsp && \
    #sed -i -e "s|###ASM_LOCATION_DATA###|$ASM_LOCATION_DATA|g" /SETUP/scripts/ora-response/dbca.rsp && \
    #sed -i -e "s|###ASM_LOCATION_ARCH###|$ASM_LOCATION_ARCH|g" /SETUP/scripts/ora-response/dbca.rsp && \
    sed -i -e "s|###STORAGETYPE###|$STORAGETYPE|g" /tmp/SETUP/ora-response/dbca.rsp && \
    sed -i -e "s|###ORACLE_BASE###|$ORACLE_BASE|g" /tmp/SETUP/ora-response/dbca.rsp
    sed -i -e "s|###WALLET_ROOT###|$WALLET_ROOT|g" /tmp/SETUP/ora-response/dbca.rsp

    $ORACLE_HOME/bin/dbca -silent -createDatabase -responseFile /tmp/SETUP/ora-response/dbca.rsp
    rm -f /tmp/SETUP/scripts/ora-response/dbca.rsp

    echo "---------------------------------------------------------"
    echo " INSTALLER: Database Created                             "
    echo "---------------------------------------------------------"

    #Used to ensure database will come up.
    export ORACLE_SID=${ORACLE_SID}

    echo "---------------------------------------------------------"
    echo " INSTALLER: Enabling Archive Logging                     "
    echo "---------------------------------------------------------"

    sh ./archivelog_force.sh

    echo "---------------------------------------------------------"
    echo " INSTALLER: DONE - Enabling Archive Logging              "
    echo "---------------------------------------------------------"

    echo "---------------------------------------------------------"
    echo " INSTALLER: Enabling Transparent Data Encryption         "
    echo "---------------------------------------------------------"

    sh ./tde_wallet.sh $WALLET_LOCATION

    echo "---------------------------------------------------------"
    echo " INSTALLER: DONE - Enabling Transparent Data Encryption  "
    echo "---------------------------------------------------------"

    echo "---------------------------------------------------------"
    echo "INSTALLER: DONE                                          "
    echo "---------------------------------------------------------"

    exit
fi #end top level if statement

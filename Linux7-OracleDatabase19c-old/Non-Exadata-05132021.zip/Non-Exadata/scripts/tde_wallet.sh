#!/bin/sh

export ORACLE_BASE=/opt/app/oracle
export ORACLE_HOME=/opt/app/oracle/product/19.3.0/dbhome_1
export WALLET_LOCATION=$1

#create wallet directory
mkdir ${WALLET_LOCATION}

#connect to database and configure TDE
${ORACLE_HOME}/bin/sqlplus / as sysdba << EOF

set linesize 175
col wrl_parameter format a50 wrap

administer key management create keystore '$WALLET_LOCATION' identified by welcome1;

select wrl_type, wrl_parameter, status, con_id from gv\$encryption_wallet;

administer key management create auto_login keystore from keystore '$WALLET_LOCATION' identified by welcome1;

administer key management set keystore open force keystore identified by welcome1;

administer key management set key FORCE KEYSTORE identified by welcome1 with backup;

select wrl_type, wrl_parameter, status, con_id from gv\$encryption_wallet;

EOF


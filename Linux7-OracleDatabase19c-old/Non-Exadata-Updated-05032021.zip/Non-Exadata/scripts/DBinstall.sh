#!/bin/bash

#Used if installing from scratch
#export DB_SHIPHOME=LINUX.X64_193000_db_home.zip

#Default envrionment settings - Update if needed
export ORA_INVENTORY=/opt/app/oraInventory
export ORACLE_BASE=/opt/app/oracle
export ORACLE_HOME=/opt/app/oracle/product/19.3.0/dbhome_1
export ORACLE_CHARACTERSET=AL32UTF8
export ORACLE_EDITION=EE
export ORACLE_PWD=Welcome1
export DB_VERSION=ORA19c

#Change as needed to build desired database (CDB/PDB)
export ORACLE_NAME=ads.cst.gov
export ORACLE_SID=ads
export TYPE=RAC
export CDBBOOLEN=true
export PDBNUMBER=1
export PDB_NAME=orclpdb
export ASM_LOCATION_DATA=+DATA
export ASM_LOCATION_ARCH=+ARCH
export STORAGETYPE=ASM
export WALLET_LOCATION=/opt/app/oracle/wallet/tde

echo "--------------------------------------------------"
echo "INSTALLER: Started up                             "
echo "--------------------------------------------------"

#fix locale
echo LANG=en_US.utf-8 >> /etc/environment
echo LC_ALL=en_US.utf-8 >> /etc/environment

echo "--------------------------------------------------------"
echo "INSTALLER: Locale Fixed                                 "
echo "--------------------------------------------------------"

cp /Setup/ora-response/dbca.rsp.tmpl /Setup/ora-response/dbca.rsp
sed -i -e "s|###ORACLE_NAME###|$ORACLE_NAME|g" /Setup/ora-response/dbca.rsp && \
sed -i -e "s|###ORACLE_SID###|$ORACLE_SID|g" /Setup/ora-response/dbca.rsp && \
sed -i -e "s|###ORACLE_TYPE###|$ORACLE_TYPE|g" /Setup/ora-response/dbca.rsp && \
sed -i -e "s|###CDBBOOLEN###|$CDBBOOLEN|g" /Setup/ora-response/dbca.rsp && \
sed -i -e "s|###PDBNUMBER###|$PDBNUMBER|g" /Setup/ora-response/dbca.rsp && \
sed -i -e "s|###PDB_NAME###|$PDB_NAME|g" /Setup/ora-response/dbca.rsp && \
sed -i -e "s|###ORACLE_PWD###|$ORACLE_PWD|g" /Setup/ora-response/dbca.rsp && \
sed -i -e "s|###ASM_LOCATION_DATA###|$ASM_LOCATION_DATA|g" /Setup/ora-response/dbca.rsp && \
sed -i -e "s|###ASM_LOCATION_ARCH###|$ASM_LOCATION_ARCH|g" /Setup/ora-response/dbca.rsp && \
sed -i -e "s|###STORAGETYPE###|$STORAGETYPE|g" /Setup/ora-response/dbca.rsp && \
sed -i -e "s|###ORACLE_BASE###|$ORACLE_BASE|g" /Setup/ora-response/dbca.rsp

su -l oracle -c "yes | $ORACLE_HOME/bin/dbca -silent -createDatabase -responseFile /Setup/ora-response/dbca.rsp"
rm -f /Setup/ora-response/dbca.rsp

echo "---------------------------------------------------------"
echo " INSTALLER: Database Created                             "
echo "---------------------------------------------------------"

echo "---------------------------------------------------------"
echo " INSTALLER: Enabling Transparent Data Encryption         "
echo "---------------------------------------------------------"

sh ./tde_wallet.sh $WALLET_LOCATION

echo "---------------------------------------------------------"
echo " INSTALLER: DONE - Enabling Transparent Data Encryption  "
echo "---------------------------------------------------------"

echo "---------------------------------------------------------"
echo "INSTALLER: DONE                                          "
echo "---------------------------------------------------------"

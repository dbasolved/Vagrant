#!/bin/bash

export DB_SHIPHOME=LINUX.X64_193000_db_home.zip
export ORA_INVENTORY=/opt/app/oraInventory
export ORACLE_BASE=/opt/app/oracle
export ORACLE_HOME=/opt/app/oracle/product/19.3.0/dbhome_1
export ORACLE_SID=orcl
export PDB_NAME=orclpdb
export ORACLE_CHARACTERSET=AL32UTF8
export ORACLE_EDITION=EE
export ORACLE_PWD=Welcome1
export DB_VERSION=ORA19c
export PDBNUMBER=2


echo "--------------------------------------------------"
echo 'INSTALLER: Started up'
echo "--------------------------------------------------"

#fix locale
echo LANG=en_US.utf-8 >> /etc/environment
echo LC_ALL=en_US.utf-8 >> /etc/environment

echo "--------------------------------------------------"
echo 'INSTALLER: Locale Fixed'
echo "--------------------------------------------------"

#install prereqs and openssl
yum -y -q reinstall glibc-common
yum -y -q install oracle-database-preinstall-19c #openssl


echo "--------------------------------------------------"
echo 'INSTALLER: Oracle database preinstall and openssl installed'
echo "--------------------------------------------------"
#adding server desktop and vncserver
#yum -y -q install xterm
#yum -y -q install tightvnc-server
#cp /lib/systemd/system/vncserver@.service /etc/systemd/system/vncserver@:1.service
#sed -i -e "s|<USER>|oracle|g" /etc/systemd/system/vncserver@:1.service

echo "--------------------------------------------------"
echo 'INSTALLER: GUI desktop and VNC Server installed'
echo "--------------------------------------------------"

#create grid user
#sudo useradd -m -g oinstall grid

echo "--------------------------------------------------"
echo 'INSTALLER: Grid User created'
echo "--------------------------------------------------"

#create directories
mkdir -pv $ORACLE_BASE && \
mkdir -pv $ORACLE_HOME && \
mkdir -pv $ORA_INVENTORY && \
#mkdir -pv $GRID_HOME

#set permissions (abit of overkill)
chown oracle:oinstall -R $ORACLE_BASE
chown oracle:oinstall -R $ORACLE_HOME
chown oracle:oinstall -R $ORA_INVENTORY


echo "--------------------------------------------------"
echo 'INSTALLER: Required Oracle directories created'
echo "--------------------------------------------------"

#set environment variables in .bashrc
echo "export ORACLE_BASE=$ORACLE_BASE" >> /home/oracle/.bashrc && \
echo "export ORACLE_HOME=$ORACLE_HOME" >> /home/oracle/.bashrc && \
echo "export LD_LIBRARY_PATH=$ORACLE_HOME/lib" >> /home/oracle/.bashrc && \
echo "export ORACLE_SID=$ORACLE_SID" >> /home/oracle/.bashrc && \
echo "export GRID_HOME=$GRID_HOME" >> /home/oracle/.bashrc && \
echo "export PATH=\$PATH:\$ORACLE_HOME/bin:\$LD_LIBRARY_PATH:\$OGG_HOME/bin" >> /home/oracle/.bashrc

echo "--------------------------------------------------"
echo "INSTALLER: Setting Environment Variables for Oracle completed"
echo "--------------------------------------------------"

#unzip grid software
#unzip -o -q /Test_Software/${GRID_SHIPHOME} -d ${GRID_HOME}
#chown grid:oinstall -R $GRID_HOME

echo "--------------------------------------------------"
echo 'INSTALLER: Grid Infrastructure installed'
echo "--------------------------------------------------"


#unzip software and configure database
unzip -o -q /Test_Software/${DB_SHIPHOME} -d ${ORACLE_HOME}
cp /Setup/ora-response/dbinstall.rsp.tmpl /Setup/ora-response/db_install.rsp
sed -i -e "s|###ORACLE_BASE###|$ORACLE_BASE|g" /Setup/ora-response/db_install.rsp && \
sed -i -e "s|###ORACLE_HOME###|$ORACLE_HOME|g" /Setup/ora-response/db_install.rsp && \
sed -i -e "s|###ORA_INVENTORY###|$ORA_INVENTORY|g" /Setup/ora-response/db_install.rsp
chown -R oracle:oinstall ${ORACLE_HOME}

su -l oracle -c "yes | ${ORACLE_HOME}/runInstaller -silent  -ignorePrereqFailure -waitforcompletion -responseFile /Setup/ora-response/db_install.rsp"
$ORA_INVENTORY/orainstRoot.sh
$ORACLE_HOME/root.sh
rm -f /Setup/ora-response/db_install.rsp

echo "--------------------------------------------------"
echo "INSTALLER: Oracle Database Software installed     "
echo "--------------------------------------------------"

#configure software
cp /Setup/ora-response/netca.rsp.tmpl /Setup/ora-response/netca.rsp
su -l oracle -c "yes | $ORACLE_HOME/bin/netca -silent -responseFile /Setup/ora-response/netca.rsp"
su -l oracle -c "lsnrctl start"
rm -f /Setup/ora-response/netca.rsp

echo "--------------------------------------------------"
echo " INSTALLER: Listener Installed                    "
echo "--------------------------------------------------"

cp /Setup/ora-response/dbca.rsp.tmpl /Setup/ora-response/dbca.rsp
sed -i -e "s|###ORACLE_SID###|$ORACLE_SID|g" /Setup/ora-response/dbca.rsp && \
sed -i -e "s|###PDB_NAME###|$PDB_NAME|g" /Setup/ora-response/dbca.rsp && \
sed -i -e "s|###ORACLE_PWD###|$ORACLE_PWD|g" /Setup/ora-response/dbca.rsp && \
sed -i -e "s|###PDBNUMBER###|$PDBNUMBER|g" /Setup/ora-response/dbca.rsp && \
sed -i -e "s|###ORACLE_BASE###|$ORACLE_BASE|g" /Setup/ora-response/dbca.rsp

su -l oracle -c "yes | $ORACLE_HOME/bin/dbca -silent -createDatabase -responseFile /Setup/ora-response/dbca.rsp"
rm -f /Setup/ora-response/dbca.rsp

echo "--------------------------------------------------"
echo " INSTALLER: Database Created                      "
echo "--------------------------------------------------"

#remove yum cache
rm -rf /var/cache/yum
rm -rf /Setup/db19c

echo "--------------------------------------------------"
echo 'INSTALLER: Done'
echo "--------------------------------------------------"

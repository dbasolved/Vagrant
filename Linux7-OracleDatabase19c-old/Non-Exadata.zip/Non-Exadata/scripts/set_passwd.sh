#!/bin/sh

echo "-----------------------------------"
echo "Setting password for Root"
echo "-----------------------------------"

echo "Welcome1" | passwd root --stdin

echo "-----------------------------------"
echo "Setting password for Oracle"
echo "-----------------------------------"

echo "Welcome1" | passwd oracle --stdin